﻿using AutoMapper;

namespace arquiteturaBase.application.AutoMapper
{
    public class DomainToDto : Profile
    {
        public DomainToDto() {}
    }
}
